#include <stdio.h>

void calcular_estatisticas(float *notas, int quantidade,
                           float *media, float *maior, float *menor) {
    // Começamos assumindo que a primeira nota (*notas) é a maior e a menor.
    // A soma também começa com o valor da primeira nota.
    float soma = *notas; // Equivale a notas[0]
    float maior_local = *notas;
    float menor_local = *notas;

    // Usamos *(notas + i) para acessar os elementos via aritmética de ponteiros.
    for (int i = 1; i < quantidade; i++) {
        float nota_atual = *(notas + i); // Equivale a notas[i]
        soma += nota_atual;

        if (nota_atual > maior_local) { 
            maior_local = nota_atual; 
        }
        if (nota_atual < menor_local) {
            menor_local = nota_atual;
        }
    }

    *media = soma / quantidade;
    *maior = maior_local;
    *menor = menor_local;
}

int main() {
    float notas[] = {8.5, 7.2, 9.1, 6.8, 8.9, 7.7, 9.5, 8.2};
    int qtd_notas = sizeof(notas) / sizeof(notas[0]);
    float media, maior, menor;

    calcular_estatisticas(notas, qtd_notas, &media, &maior, &menor);

    printf("--- Estatísticas das Notas ---\n");
    printf("Notas: ");
    for (int i = 0; i < qtd_notas; i++) {
        printf("%.1f/ ", notas[i]);
    }
    printf("\n\n");
    printf("Média das notas: %.2f\n", media);
    printf("Maior nota:      %.1f\n", maior);
    printf("Menor nota:      %.1f\n", menor);

    return 0;
}