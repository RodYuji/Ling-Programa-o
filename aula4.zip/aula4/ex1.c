#include <stdio.h>

int main(){
    float salario = 2500.50;
    float *ponteiro_salario;

    ponteiro_salario = &salario;

    printf("Valor de salário inicial: %.2f\n", *ponteiro_salario); //ponteiro aponta para salário
    printf("Endereço de salário: %p\n", &salario); 
    printf("Valor de ptr: %p\n", ponteiro_salario); // imprimir valor pelo ponteiro
    *ponteiro_salario = 3000.00;
    printf("Valor apontado por ptr final: %.2f\n", salario);

    return 0;

}