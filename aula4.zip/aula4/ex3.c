#include <stdio.h>


int encontrar_maior(int *array, int tamanho) {
    // ptr_maior guarda o ENDEREÇO do maior elemento encontrado até agora.
    int *ptr_maior = array;
    int *ptr_atual;
    // O loop começa no primeiro elemento e continua enquanto o endereço de ptr_atual for menor que o endereço do final do array (array + tamanho).
    for (ptr_atual = array; ptr_atual < array + tamanho; ptr_atual++) {
        if (*ptr_atual > *ptr_maior) {
            ptr_maior = ptr_atual;
        }
    }
    return *ptr_maior;
}

int main() {
    int numeros[] = {45, 23, 78, 12, 67, 34, 89, 56};
    int tamanho = sizeof(numeros) / sizeof(numeros[0]);

    int maior = encontrar_maior(numeros, tamanho);

    printf("Array: ");
    for(int i = 0; i < tamanho; i++){
        printf("%d ", numeros[i]);
    }
    printf("\nMaior elemento: %d\n", maior);

    return 0;
}