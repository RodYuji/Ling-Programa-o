#include <stdio.h>
#include <string.h>

void inverter_string(char *str) {

    // 'inicio' aponta para o primeiro caractere da string.
    char *inicio = str;
    
    // 'fim' aponta para o ÚLTIMO caractere da string (antes do terminador nulo '\0').
    char *fim = str + strlen(str) - 1;

    // 3. Loop de troca (swap)
    // O loop continua enquanto o ponteiro do início não tiver alcançado ou ultrapassado o do fim.
    while (inicio < fim) {
        // a. Armazena o caractere do início em uma variável temporária.
        char temp = *inicio;

        // b. Copia o caractere do fim para a posição do início.
        *inicio = *fim;

        // c. Copia o caractere que estava no início (agora em 'temp') para a posição do fim.
        *fim = temp;

        // d. Move os ponteiros em direção ao centro da string.
        inicio++;
        fim--;
    }
}

int main() {
    char texto[100] = ""; //crie uma string vazia de tamanho 99 + 1 caracter nulo
    printf("Digite a palavra para ser invertida: ");
    scanf("%s", texto);

    printf("String original: %s\n", texto);
    inverter_string(texto);
    printf("String invertida: %s\n", texto);

    return 0;
}