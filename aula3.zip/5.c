#include <stdio.h>

int main(){
    int maior, i, j, matriz[2][3];
    for (i = 0; i < 2; i++){
        for (j = 0; j < 3; j++){
            printf("Digite o valor do elemento %dx%d: ", i+1, j+1);
            scanf("%d", &matriz[i][j]);
        }
    }
    for (i = 0; i < 2; i++){
        for (j = 0; j < 3; j++){
            printf("%d | ", matriz[i][j]);
        }
        printf("\n");
    }
    printf("\n--- MAIORES QUE 5 ---\n");
    for (i = 0; i < 2; i++){
        for (j = 0; j < 3; j++){
            if (matriz[i][j] > 5){
                printf("%d | ", matriz[i][j]);
            }
        }
    }
    return 0;
}