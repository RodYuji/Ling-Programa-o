//Criar um programa que leia 4 números, armazene em um vetor e calcule a média

#include <stdio.h>

int main(){
    int i;
    float soma = 0, media, num[4];
    for (i = 0; i < 4; i++){
        printf("Digite o número: ");
        scanf("%f", &num[i]);
        soma += num[i];
    }
    printf("\n--- MÉDIA ---\n");
    media = soma/4;
    printf("A média dos números é: %.2f", media);
    return 0;

}