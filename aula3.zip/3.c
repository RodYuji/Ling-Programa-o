#include <stdio.h>

int main(){
    int maior, i, j, matriz[2][2];
    for (i = 0; i < 2; i++){
        for (j = 0; j < 2; j++){
            printf("Digite o valor do elemento %dx%d: ", i+1, j+1);
            scanf("%d", &matriz[i][j]);
        }
    }
    for (i = 0; i < 2; i++){
        for (j = 0; j < 2; j++){
            printf("%d | ", matriz[i][j]);
        }
        printf("\n");
    }
    printf("\n--- MAIOR NÚMERO ---\n");

    maior = matriz[0][0];
    for (i = 0; i < 2; i++){
        for (j = 0; j < 2; j++){
            if (matriz[i][j] > maior){
                maior = matriz[i][j];
            } 
        }
    }
    printf("O maior número da matriz é %d", maior);
    return 0;
}