//Ler 5 números e mostrar apenas os maiores que 10

#include <stdio.h>

int main(){
    int i, num[5];
    for (i = 0; i < 5; i++){
        printf("Digite o %dº número: ", i+1);
        scanf("%d", &num[i]);
    }
    printf("\n --- OS NÚMEROS MAIORES QUE 10 ---\n");
    for (i = 0; i < 5; i++){
        if (num[i] > 10){
            printf("%d\n", num[i]);
        }
    }
    return 0;
}