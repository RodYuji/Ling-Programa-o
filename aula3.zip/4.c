#include <stdio.h>

int main(){
    int soma = 0, i, j, matriz[3][3];
    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            printf("Digite o valor do elemento %dx%d: ", i+1, j+1);
            scanf("%d", &matriz[i][j]);
        }
    }
    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            printf("%d | ", matriz[i][j]);
        }
        printf("\n");
    }
    for (i = 0; i < 3; i++){
        for (j = 0; j < 3; j++){
            if (i == j){
                soma += matriz[i][j];
            }
        }
    }
    printf("\n--- SOMA ---\n");
    printf("A soma da diagonal principal é: %d", soma);
    return 0;
}